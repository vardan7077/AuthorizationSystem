import React from 'react';
import Style from './SignInEmail.module.css'
const SignInEmail = () => {
    return (
        <div className={Style.SignIn}>
            <div>
                Email:
            <input></input>
            </div>
            <div>
                Password:
            <input></input>
            </div>
            <button>SignIn</button>
        </div>
    )
}

export default SignInEmail