import React from 'react';
import Style from './Create-acc.module.css'
const SignUp = () => {
  return (

    <div className={Style.SignUp}>
      <div>
        Full name:
            <input></input>
      </div>
      <div>
        Email:
            <input></input>
      </div>
      <div>
        Password:
            <input></input>
      </div>
      <div>
        Repeate the password:
            <input></input>
      </div>
      <button>Create an account</button>
    </div>

  )
}

export default SignUp