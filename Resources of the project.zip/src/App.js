import React from 'react';
import SignUp from './SignUp/SignUp'
import SignUpEmail from './SignUp/SignUpEmail/SignUpEmail'
import SignInEmail from './SignIn/SignInEmail/SignInEmail'
import SignIn from './SignIn/SignIn'
import Autorization from './Autorization/Autorization'

import { BrowserRouter, Switch, Route } from 'react-router-dom';

const App = () => {
  return (
    <BrowserRouter>

      <div>
      <Switch>
        <Route exact path = '/' component={Autorization} />
        <Route path='/SignInEmail' component={SignInEmail} />
        <Route path='/SignIn' component={SignIn} />
        <Route path='/SignUp' component={SignUp} />
        <Route path='/SignUpEmail' component={SignUpEmail} />
      </Switch>
      </div>
    </BrowserRouter>
  );
}



export default App;
